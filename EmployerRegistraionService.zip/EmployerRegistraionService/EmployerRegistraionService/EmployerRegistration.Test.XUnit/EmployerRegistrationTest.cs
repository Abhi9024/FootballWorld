using EmployerRegistraionService.Controllers;
using EmployerRegistration.Model;
using EmployerRegistration.Test.XUnit.Helper;
using Xunit;

namespace EmployerRegistration.Test.XUnit
{
    public class EmployerRegistrationTest
    {
        EmployerTestHelper helper = new EmployerTestHelper();

        [Fact]
        public void AddEmployerRegistrationTest()
        {
            //arrange
            var inputData = new EmployerResgistrationViewModel() {CaseId =2};
            int result = 1;
            EmployerRegistrationController employerRegistrationService = new EmployerRegistrationController(helper.AddEmployerRegistrationTest(inputData, result));
            //act
            var expectedResult = employerRegistrationService.Post(inputData);
            //assert
            Assert.Equal(expectedResult, result);
        }

        [Fact]
        public void VerifyEmployerRegistrationTest()
        {
            //arrange
            string hasedId = "etdfgd34";
            var inputData = new EmployerResgistrationViewModel() { CaseId = 2 };
            bool result = true;
            EmployerRegistrationController employerRegistrationService = new EmployerRegistrationController(helper.VerifyEmployerRegistrationTest(hasedId,inputData,result));
            //act
            var expectedResult = employerRegistrationService.Put(hasedId,inputData);
            //assert
            Assert.Equal(expectedResult, result);
        }

    }
}

﻿using EmployerRegistraionService.Controllers;
using EmployerRegistration.Model;
using EmployerRegistration.Test.XUnit.Helper;
using Xunit;

namespace EmployerRegistration.Test.XUnit
{
    public class EmployerProfileTest
    {
        EmployerTestHelper helper = new EmployerTestHelper();

        [Fact]
        public void AddEmployerProfileTest()
        {
            //arrange
            var inputData = new EmployerProfileInfoViewModel() {CaseId=2 };
            int result = 1;
            EmployerProfileController employerProfileService = new EmployerProfileController(helper.AddEmployerProfileTest(inputData,result));
            //act
            var actualResult = employerProfileService.Post(inputData);
            //assert
            Assert.Equal(actualResult, result);
        }
    }
}

﻿using AutoMapper;
using EmployerRegistration.DataProvider.EFRepository;
using EmployerRegistration.DataProvider.IRepository;
using EmployerRegistration.Model;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;

namespace EmployerRegistration.Test.XUnit.Helper
{
    public class EmployerTestHelper
    {
        private readonly string testmethod = "moq";

        Mock<IEmployerRegistrationDataProvider> employerRegistrationMock = new Mock<IEmployerRegistrationDataProvider>();
        Mock<IEmployerLoginDataProvider> employerLoginMock = new Mock<IEmployerLoginDataProvider>();
        Mock<IEmployerProfileDataProvider> employerProfileMock = new Mock<IEmployerProfileDataProvider>();
        private IMapper mapper;

        public IEmployerRegistrationDataProvider AddEmployerRegistrationTest(EmployerResgistrationViewModel inputData, int result)
        {
            if (testmethod == "moq")
            {
                employerRegistrationMock.Setup(s => s.AddEmployerRegistrationInfo(inputData)).Returns(result);
                return employerRegistrationMock.Object;
            }
            else
            {
                var mapperConfig = new MapperConfiguration(cfg =>
                {
                    cfg.AddProfile(new EmployerAutoMapperTest());
                });
                mapper = mapperConfig.CreateMapper();

                return new EmployerRegistrationDataProvider(mapper, new DependencyResolver().ConnectionStrings);
            }
        }

        public IEmployerRegistrationDataProvider VerifyEmployerRegistrationTest(string id, EmployerResgistrationViewModel inputData, bool result)
        {
            if (testmethod == "moq")
            {
                employerRegistrationMock.Setup(s => s.VerifyRegistrationInfo(id, inputData)).Returns(result);
                return employerRegistrationMock.Object;
            }
            else
            {
                var mapperConfig = new MapperConfiguration(cfg =>
                {
                    cfg.AddProfile(new EmployerAutoMapperTest());
                });
                mapper = mapperConfig.CreateMapper();

                return new EmployerRegistrationDataProvider(mapper, new DependencyResolver().ConnectionStrings);
            }
        }

        public IEmployerLoginDataProvider AddEmployerLoginTest(EmployerLoginViewModel inputData, int result)
        {
            if (testmethod == "moq")
            {
                employerLoginMock.Setup(s => s.AddEmployerLoginInfo(inputData)).Returns(result);
                return employerLoginMock.Object;
            }
            else
            {
                var mapperConfig = new MapperConfiguration(cfg =>
                {
                    cfg.AddProfile(new EmployerAutoMapperTest());
                });
                mapper = mapperConfig.CreateMapper();

                return new EmployerLoginDataProvider(mapper, new DependencyResolver().ConnectionStrings);
            }
        }

        public IEmployerProfileDataProvider AddEmployerProfileTest(EmployerProfileInfoViewModel inputData, int result)
        {
            if (testmethod == "moq")
            {
                employerProfileMock.Setup(s => s.AddEmployerProfileInfo(inputData)).Returns(result);
                return employerProfileMock.Object;
            }
            else
            {
                var mapperConfig = new MapperConfiguration(cfg =>
                {
                    cfg.AddProfile(new EmployerAutoMapperTest());
                });
                mapper = mapperConfig.CreateMapper();

                return new EmployerProfileDataProvider(mapper, new DependencyResolver().ConnectionStrings);
            }
        }
    }
}


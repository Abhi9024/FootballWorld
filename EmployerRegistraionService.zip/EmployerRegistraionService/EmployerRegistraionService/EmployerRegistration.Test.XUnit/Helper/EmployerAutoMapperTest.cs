﻿using AutoMapper;
using EmployerRegistration.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace EmployerRegistration.Test.XUnit.Helper
{
    public class EmployerAutoMapperTest :Profile
    {
        public EmployerAutoMapperTest()
        {
            CreateMap<DataProvider.EFCore.Models.EmployerResgistrationInfo, EmployerResgistrationViewModel>().ReverseMap();
            CreateMap<DataProvider.EFCore.Models.EmployerProfileInfo, EmployerProfileInfoViewModel>().ReverseMap();
            CreateMap<DataProvider.EFCore.Models.EmployerContactInfo, EmployerContactInfoViewModel>().ReverseMap();
            CreateMap<DataProvider.EFCore.Models.EmployerLoginInfo, EmployerLoginViewModel>().ReverseMap();
        }
    }
}

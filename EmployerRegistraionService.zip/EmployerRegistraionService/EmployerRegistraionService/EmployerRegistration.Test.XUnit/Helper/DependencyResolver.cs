﻿using AutoMapper;
using EmployerRegistration.DataProvider.EFRepository;
using EmployerRegistration.DataProvider.IRepository;
using EmployerRegistration.Model;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Text;


namespace EmployerRegistration.Test.XUnit.Helper
{
    public class DependencyResolver
    {
        private readonly IConfigurationRoot Configuration;
        private readonly IServiceProvider _serviceProvider;

        public IOptions<ConnectionString> ConnectionStrings { get; set; }

        public DependencyResolver()
        {
            var builder = new ConfigurationBuilder()
                          .AddJsonFile("testsettings.json")
                          .AddEnvironmentVariables();
            Configuration = builder.Build();

            var services = new ServiceCollection();
            services.AddOptions();
            services.AddAutoMapper();
            services.Configure<ConnectionString>(Configuration.GetSection("ConnectionString"));
            services.Configure<byte[]>(Configuration.GetSection("ImageByte"));

            services.AddTransient<IEmployerRegistrationDataProvider, EmployerRegistrationDataProvider>();
            services.AddTransient<IEmployerProfileDataProvider, EmployerProfileDataProvider>();
            services.AddTransient<IEmployerLoginDataProvider, EmployerLoginDataProvider>();
            _serviceProvider = services.BuildServiceProvider();
            ConnectionStrings = _serviceProvider.GetService<IOptions<ConnectionString>>();
        }
    }
}

﻿using EmployerRegistraionService.Controllers;
using EmployerRegistration.Model;
using EmployerRegistration.Test.XUnit.Helper;
using Xunit;

namespace EmployerRegistration.Test.XUnit
{
    public class EmployerLoginTest
    {
        EmployerTestHelper helper = new EmployerTestHelper();

        [Fact]
        public void AddEmployerLoginTest()
        {
            //arrange
            var inputData = new EmployerLoginViewModel() { CaseId=2 };
            int result = 1;

            EmployerLoginController employerLoginService = new EmployerLoginController(helper.AddEmployerLoginTest(inputData, result));
            //act
            var actualResult = employerLoginService.Post(inputData);

            //assert
            Assert.Equal(actualResult, result);
        }
    }
}

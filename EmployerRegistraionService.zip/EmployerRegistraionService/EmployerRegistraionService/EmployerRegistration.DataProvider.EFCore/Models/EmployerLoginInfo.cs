﻿using System;
using System.Collections.Generic;

namespace EmployerRegistration.DataProvider.EFCore.Models
{
    public partial class EmployerLoginInfo
    {
        public long Id { get; set; }
        public long CaseId { get; set; }
        public long Erid { get; set; }
        public string UserId { get; set; }
        public string Password { get; set; }
        public Guid PasswordKey { get; set; }
        public long QuestionId { get; set; }
        public string Answer { get; set; }
        public DateTime? CreatedDate { get; set; }
        public long? CreatedUser { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public long? ModifiedUser { get; set; }

        public virtual EmployerResgistrationInfo Er { get; set; }
        public virtual SecurityQuestion Question { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

namespace EmployerRegistration.DataProvider.EFCore.Models
{
    public partial class EmployerResgistrationInfo
    {
        public long Id { get; set; }
        public byte[] HashedId { get; set; }
        public long CaseId { get; set; }
        public long FederalTaxId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string AdditionalText { get; set; }
        public bool? IsActive { get; set; }
        public DateTime? CreatedDate { get; set; }
        public long? CreatedUser { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public long? ModifiedUser { get; set; }

        public virtual EmployerCoverageTypeInfo EmployerCoverageTypeInfo { get; set; }
        public virtual EmployerLoginInfo EmployerLoginInfo { get; set; }
        public virtual EmployerProfileInfo EmployerProfileInfo { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

namespace EmployerRegistration.DataProvider.EFCore.Models
{
    public partial class EmployerContactInfo
    {
        public long Id { get; set; }
        public long CaseId { get; set; }
        public long ProfileId { get; set; }
        public long? TypeId { get; set; }
        public long? Number { get; set; }
        public long? Extension { get; set; }
        public int? Sequence { get; set; }
        public string Email { get; set; }
        public DateTime? CreatedDate { get; set; }
        public long? CreatedUser { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public long? ModifiedUser { get; set; }

        public virtual EmployerProfileInfo Profile { get; set; }
    }
}

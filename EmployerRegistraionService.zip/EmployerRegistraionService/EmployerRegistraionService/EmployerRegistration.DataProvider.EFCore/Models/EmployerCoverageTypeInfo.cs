﻿using System;
using System.Collections.Generic;

namespace EmployerRegistration.DataProvider.EFCore.Models
{
    public partial class EmployerCoverageTypeInfo
    {
        public long Id { get; set; }
        public long CaseId { get; set; }
        public long Erid { get; set; }
        public string CoverageTypeId { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public long? ZipCode { get; set; }
        public DateTime? CreatedDate { get; set; }
        public long? CreatedUser { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public long? ModifiedUser { get; set; }

        public virtual EmployerResgistrationInfo Er { get; set; }
    }
}

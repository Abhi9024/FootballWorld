﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace EmployerRegistration.DataProvider.EFCore.Models
{
    public partial class EmployerRegistrationContext : DbContext
    {
        private string connection;

        public EmployerRegistrationContext(string conn)
        {
            connection = conn;
        }

        public virtual DbSet<CoverageType> CoverageType { get; set; }
        public virtual DbSet<EmployerContactInfo> EmployerContactInfo { get; set; }
        public virtual DbSet<EmployerCoverageTypeInfo> EmployerCoverageTypeInfo { get; set; }
        public virtual DbSet<EmployerLoginInfo> EmployerLoginInfo { get; set; }
        public virtual DbSet<EmployerProfileInfo> EmployerProfileInfo { get; set; }
        public virtual DbSet<EmployerResgistrationInfo> EmployerResgistrationInfo { get; set; }
        public virtual DbSet<SecurityQuestion> SecurityQuestion { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(connection);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CoverageType>(entity =>
            {
                entity.HasKey(e => e.TypeId)
                    .HasName("PK_CoverageType");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasColumnType("varchar(max)");

                entity.Property(e => e.Type)
                    .IsRequired()
                    .HasColumnType("varchar(100)");
            });

            modelBuilder.Entity<EmployerContactInfo>(entity =>
            {
                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasColumnType("varchar(200)");

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.HasOne(d => d.Profile)
                    .WithMany(p => p.EmployerContactInfo)
                    .HasForeignKey(d => d.ProfileId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_EmployerContactInfo_EmployerProfileInfo");
            });

            modelBuilder.Entity<EmployerCoverageTypeInfo>(entity =>
            {
                entity.HasIndex(e => e.Erid)
                    .HasName("IX_EmployerCoverageTypeInfo")
                    .IsUnique();

                entity.Property(e => e.CoverageTypeId).HasColumnType("nchar(10)");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.EffectiveDate).HasColumnType("date");

                entity.Property(e => e.Erid).HasColumnName("ERId");

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.HasOne(d => d.Er)
                    .WithOne(p => p.EmployerCoverageTypeInfo)
                    .HasForeignKey<EmployerCoverageTypeInfo>(d => d.Erid)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_EmployerCoverageTypeInfo_EmployerResgistrationInfo");
            });

            modelBuilder.Entity<EmployerLoginInfo>(entity =>
            {
                entity.HasIndex(e => e.Erid)
                    .HasName("IX_EmployerLoginInfo")
                    .IsUnique();

                entity.HasIndex(e => e.UserId)
                    .HasName("IX_EmployerLoginInfo_1")
                    .IsUnique();

                entity.Property(e => e.Answer)
                    .IsRequired()
                    .HasColumnType("varchar(200)");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.Erid).HasColumnName("ERId");

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasColumnType("char(40)");

                entity.Property(e => e.UserId)
                    .IsRequired()
                    .HasColumnType("varchar(200)");

                entity.HasOne(d => d.Er)
                    .WithOne(p => p.EmployerLoginInfo)
                    .HasForeignKey<EmployerLoginInfo>(d => d.Erid)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_EmployerLoginInfo_EmployerResgistrationInfo");

                entity.HasOne(d => d.Question)
                    .WithMany(p => p.EmployerLoginInfo)
                    .HasForeignKey(d => d.QuestionId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_EmployerLoginInfo_SecurityQuestion");
            });

            modelBuilder.Entity<EmployerProfileInfo>(entity =>
            {
                entity.HasIndex(e => e.Erid)
                    .HasName("IX_EmployerContactInfo")
                    .IsUnique();

                entity.Property(e => e.AddressLine1).HasColumnType("varchar(200)");

                entity.Property(e => e.AddressLine2).HasColumnType("varchar(200)");

                entity.Property(e => e.City).HasColumnType("varchar(50)");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.Erid).HasColumnName("ERId");

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasColumnType("varchar(100)");

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasColumnType("varchar(100)");

                entity.Property(e => e.MiddleName).HasColumnType("varchar(50)");

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.Suffix).HasColumnType("varchar(10)");

                entity.HasOne(d => d.Er)
                    .WithOne(p => p.EmployerProfileInfo)
                    .HasForeignKey<EmployerProfileInfo>(d => d.Erid)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_EmployerContactInfo_EmployerResgistrationInfo");
            });

            modelBuilder.Entity<EmployerResgistrationInfo>(entity =>
            {
                entity.Property(e => e.AdditionalText).HasColumnType("varchar(max)");

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasColumnType("varchar(100)");

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasColumnType("varchar(100)");

                entity.Property(e => e.HashedId)
                    .HasColumnType("binary(50)");

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasColumnType("varchar(100)");

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<SecurityQuestion>(entity =>
            {
                entity.HasKey(e => e.QuestionId)
                    .HasName("PK_SecurityQuestion");

                entity.Property(e => e.Question)
                    .IsRequired()
                    .HasColumnType("varchar(200)");
            });
        }
    }
}
﻿using System;
using System.Collections.Generic;

namespace EmployerRegistration.DataProvider.EFCore.Models
{
    public partial class SecurityQuestion
    {
        public SecurityQuestion()
        {
            EmployerLoginInfo = new HashSet<EmployerLoginInfo>();
        }

        public long QuestionId { get; set; }
        public string Question { get; set; }

        public virtual ICollection<EmployerLoginInfo> EmployerLoginInfo { get; set; }
    }
}

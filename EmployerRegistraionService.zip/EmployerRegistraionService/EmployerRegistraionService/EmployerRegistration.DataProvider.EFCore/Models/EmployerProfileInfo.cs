﻿using System;
using System.Collections.Generic;

namespace EmployerRegistration.DataProvider.EFCore.Models
{
    public partial class EmployerProfileInfo
    {
        public EmployerProfileInfo()
        {
            EmployerContactInfo = new HashSet<EmployerContactInfo>();
        }

        public long Id { get; set; }
        public long Erid { get; set; }
        public long CaseId { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Suffix { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public long State { get; set; }
        public long ZipCode { get; set; }
        public DateTime? CreatedDate { get; set; }
        public long? CreatedUser { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public long? ModifiedUser { get; set; }

        public virtual ICollection<EmployerContactInfo> EmployerContactInfo { get; set; }
        public virtual EmployerResgistrationInfo Er { get; set; }
    }
}

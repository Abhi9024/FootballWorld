﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace EmployerRegistration.BusinessLayer.Encryptor
{
    public static class DataEncryptor
    {
        public static Guid GenerateRandomNumber()
        {
            var guid = Guid.NewGuid();
            return guid;
        }

        public static string HashPaswordWithSalt(string password, Guid randomNumber)
        {
            using (var sha256 = SHA256.Create())
            {
                byte[] combinePwd = CombinePwdWithSalt(Encoding.UTF8.GetBytes(password), randomNumber.ToByteArray());
                return Encoding.UTF8.GetString(sha256.ComputeHash(combinePwd));
            }
        }

        private static byte[] CombinePwdWithSalt(byte[] v1, byte[] v2)
        {
            var result = new byte[v1.Length + v2.Length];
            Buffer.BlockCopy(v1, 0, result, 0, v1.Length);
            Buffer.BlockCopy(v2, 0, result, v1.Length, v2.Length);
            return result;
        }

        public static byte[] GetHashedEmployerId(byte[] employerId)
        {
            using (var sha256 = SHA256.Create())
            {
                return sha256.ComputeHash(employerId);
            }
        }
    }
}

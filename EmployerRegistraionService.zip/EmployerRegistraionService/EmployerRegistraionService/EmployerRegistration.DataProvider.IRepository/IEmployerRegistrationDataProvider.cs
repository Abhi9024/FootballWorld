﻿using EmployerRegistration.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace EmployerRegistration.DataProvider.IRepository
{
    public interface IEmployerRegistrationDataProvider
    {
        List<EmployerResgistrationViewModel> GetAll();
        int AddEmployerRegistrationInfo(EmployerResgistrationViewModel model);
        bool VerifyRegistrationInfo(string id,EmployerResgistrationViewModel model);
    }
}

﻿using EmployerRegistration.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace EmployerRegistration.DataProvider.IRepository
{
    public interface IEmployerLoginDataProvider
    {
        int AddEmployerLoginInfo(EmployerLoginViewModel model);
        List<EmployerLoginViewModel> GetEmployerLoginInfo();
    }
}

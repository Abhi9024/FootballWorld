﻿using AutoMapper;
using EmployerRegistration.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployerRegistraionService.AutoMapper
{
    public class EmployerRegistrationMapper : Profile
    {
        public EmployerRegistrationMapper()
        {
            CreateMap<EmployerRegistration.DataProvider.EFCore.Models.EmployerResgistrationInfo, EmployerResgistrationViewModel>().ReverseMap();
            CreateMap<EmployerRegistration.DataProvider.EFCore.Models.EmployerProfileInfo, EmployerProfileInfoViewModel>().ReverseMap();
            CreateMap<EmployerRegistration.DataProvider.EFCore.Models.EmployerContactInfo, EmployerContactInfoViewModel>().ReverseMap();
            CreateMap<EmployerRegistration.DataProvider.EFCore.Models.EmployerLoginInfo, EmployerLoginViewModel>().ReverseMap();
        }
    }
}

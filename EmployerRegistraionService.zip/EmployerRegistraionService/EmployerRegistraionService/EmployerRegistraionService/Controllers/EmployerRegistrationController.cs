﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using EmployerRegistration.Model;
using EmployerRegistration.DataProvider.IRepository;
using System.Net;

namespace EmployerRegistraionService.Controllers
{
    [Route("api/EmployerRegistration")]
    public class EmployerRegistrationController : Controller
    {
        private IEmployerRegistrationDataProvider employerRegistrationDataProvider;

        public EmployerRegistrationController(IEmployerRegistrationDataProvider dataProvider)
        {
            employerRegistrationDataProvider = dataProvider;
        }
        // GET: api/EmployerRegistration/GetAll
        [HttpGet]
        [Route("GetAll")]
        public List<EmployerResgistrationViewModel> Get()
        {
            return employerRegistrationDataProvider.GetAll();
        }

        // POST api/EmployerRegistration/Add
        [HttpPost]
        [Route("Add")]
        public int Post([FromBody]EmployerResgistrationViewModel model)
        {
            var result = employerRegistrationDataProvider.AddEmployerRegistrationInfo(model);
            if (result == 1)
            {
                //send email
            }
            return result;
        }

        // PUT api/EmployerRegistration/Autenticate
        [HttpPut("{id}")]
        [Route("Autenticate")]
        public bool Put(string id, [FromBody]EmployerResgistrationViewModel model)
        {
            var result = employerRegistrationDataProvider.VerifyRegistrationInfo(id, model);
            return result;
        }
    }
}

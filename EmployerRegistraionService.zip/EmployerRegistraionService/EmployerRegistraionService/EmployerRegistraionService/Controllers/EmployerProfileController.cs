﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using EmployerRegistration.DataProvider.IRepository;
using EmployerRegistration.Model;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EmployerRegistraionService.Controllers
{
    [Route("api/EmployerProfile")]
    public class EmployerProfileController : Controller
    {
        private IEmployerProfileDataProvider employerProfileDataProvider;

        public EmployerProfileController(IEmployerProfileDataProvider dataProvider)
        {
            employerProfileDataProvider = dataProvider;
        }

        // GET: api/EmployerProfile/GetAll
        [HttpGet]
        [Route("GetAll")]
        public List<EmployerProfileInfoViewModel> Get()
        {
            return employerProfileDataProvider.GetEmployerProfileInfo();
        }

        // POST api/EmployerProfile/Add
        [HttpPost]
        [Route("Add")]
        public int Post([FromBody]EmployerProfileInfoViewModel data)
        {
            var result = employerProfileDataProvider.AddEmployerProfileInfo(data);
            return result;
        }
    }
}

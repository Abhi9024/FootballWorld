﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using EmployerRegistration.DataProvider.IRepository;
using EmployerRegistration.Model;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EmployerRegistraionService.Controllers
{
    [Route("api/EmployerLogin")]
    public class EmployerLoginController : Controller
    {
        private IEmployerLoginDataProvider employerLoginDataProvider;

        public EmployerLoginController(IEmployerLoginDataProvider dataProvider)
        {
            employerLoginDataProvider = dataProvider;
        }

        // GET: api/EmployerLogin/GetAll
        [HttpGet]
        [Route("GetAll")]
        public List<EmployerLoginViewModel> Get()
        {
            return employerLoginDataProvider.GetEmployerLoginInfo();
        }

        // POST api/EmployerLogin/Add
        [HttpPost]
        [Route("Add")]
        public int Post([FromBody]EmployerLoginViewModel formData)
        {
            var result = employerLoginDataProvider.AddEmployerLoginInfo(formData);
            return result;
        }

    }
}

﻿using System;

namespace EmployerRegistration.Model
{
    public class EmployerContactInfoViewModel
    {
        public long CaseId { get; set; }
        public long ProfileId { get; set; }
        public long? TypeId { get; set; }
        public long? Number { get; set; }
        public long? Extension { get; set; }
        public int? Sequence { get; set; }
        public string Email { get; set; }
        public DateTime? CreatedDate { get; set; }
        public long? CreatedUser { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public long? ModifiedUser { get; set; }
    }
}
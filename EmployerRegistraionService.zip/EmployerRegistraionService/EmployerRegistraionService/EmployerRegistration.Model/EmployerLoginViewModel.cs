﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmployerRegistration.Model
{
    public class EmployerLoginViewModel
    {
        public long CaseId { get; set; }
        public long Erid { get; set; }
        public string UserId { get; set; }
        public string Password { get; set; }
        public Guid PasswordKey { get; set; }
        public long QuestionId { get; set; }
        public string Answer { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmployerRegistration.Model
{
    public class EmployerResgistrationViewModel
    {
        public byte[] HashedId { get; set; }
        public long CaseId { get; set; }
        public long FederalTaxId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string AdditionalText { get; set; }
        public bool? IsActive { get; set; }
    }
}

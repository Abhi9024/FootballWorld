﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmployerRegistration.Model
{
    public class EmployerProfileInfoViewModel
    {
        public long Erid { get; set; }
        public long CaseId { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Suffix { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public long State { get; set; }
        public long ZipCode { get; set; }

        public virtual ICollection<EmployerContactInfoViewModel> EmployerContactInfo { get; set; }
    }
}

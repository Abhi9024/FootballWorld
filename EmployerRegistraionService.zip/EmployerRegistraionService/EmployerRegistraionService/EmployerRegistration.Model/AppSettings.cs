﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmployerRegistration.Model
{
    public class AppSettings
    {
        public ConnectionString ConnectionString { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmployerRegistration.Model
{
    public class ConnectionString
    {
        public string EmployerRegistrationDB { get; set; }
    }
}

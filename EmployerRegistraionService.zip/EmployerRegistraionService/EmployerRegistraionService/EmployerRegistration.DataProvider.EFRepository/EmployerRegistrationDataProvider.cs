﻿using EmployerRegistration.DataProvider.IRepository;
using System;
using System.Collections.Generic;
using System.Text;
using EmployerRegistration.Model;
using AutoMapper;
using Microsoft.Extensions.Options;
using EmployerRegistration.DataProvider.EFCore.Models;
using System.Security.Cryptography;
using System.Linq;
using EmployerRegistration.BusinessLayer.Encryptor;

namespace EmployerRegistration.DataProvider.EFRepository
{
    public class EmployerRegistrationDataProvider : IEmployerRegistrationDataProvider
    {
        private IMapper mapper;
        private ConnectionString connection;

        public EmployerRegistrationDataProvider(IMapper map,IOptions<ConnectionString> conn)
        {
            mapper = map;
            connection = conn.Value;
        }


        public int AddEmployerRegistrationInfo(EmployerResgistrationViewModel model)
        {
            int result = 0;
            EmployerRegistrationContext employerRegistrationContext = new EmployerRegistrationContext(connection.EmployerRegistrationDB);
            if (model != null)
            {
                var coreData = mapper.Map<EmployerResgistrationInfo>(model);
                employerRegistrationContext.EmployerResgistrationInfo.Add(coreData);
                result = employerRegistrationContext.SaveChanges();
                InsertHashedEmployerId(coreData.Id, employerRegistrationContext);
            }

            return result;
        }

        private void InsertHashedEmployerId(long employerId, EmployerRegistrationContext employerRegistrationContext)
        {
            var hashedEmployerId = DataEncryptor.GetHashedEmployerId(BitConverter.GetBytes(employerId));

            var existingData = employerRegistrationContext.EmployerResgistrationInfo.Where(e => e.Id == employerId).FirstOrDefault();
        
            if (existingData != null)
            {
                existingData.HashedId = hashedEmployerId;

                employerRegistrationContext.EmployerResgistrationInfo.Attach(existingData);
                employerRegistrationContext.Entry(existingData).Property(r => r.HashedId).IsModified = true;
                employerRegistrationContext.SaveChanges();
            }
        }

        public bool VerifyRegistrationInfo(string id,EmployerResgistrationViewModel model)
        {
            EmployerRegistrationContext employerRegistrationContext = new EmployerRegistrationContext(connection.EmployerRegistrationDB);

            var data = employerRegistrationContext
                       .EmployerResgistrationInfo
                       .Where(r=>r.FirstName == model.FirstName && 
                              r.LastName == model.LastName && 
                              r.FederalTaxId == model.FederalTaxId).FirstOrDefault();
            if (data != null)
            {
                var hashedId = Convert.ToBase64String(data.HashedId);
                return (hashedId == id) ? true : false;
            }
            else
            {
                return false;
            }
        }

        public List<EmployerResgistrationViewModel> GetAll()
        {
            EmployerRegistrationContext employerRegistrationContext = new EmployerRegistrationContext(connection.EmployerRegistrationDB);
            var data =  employerRegistrationContext.EmployerResgistrationInfo.Where(r => r.Id > 0).ToList();
            var result = mapper.Map<List<EmployerResgistrationViewModel>>(data);
            return result;
        }
    }
}

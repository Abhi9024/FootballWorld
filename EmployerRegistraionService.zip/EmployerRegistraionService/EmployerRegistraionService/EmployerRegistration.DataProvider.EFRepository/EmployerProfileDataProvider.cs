﻿using EmployerRegistration.DataProvider.IRepository;
using System;
using System.Collections.Generic;
using System.Text;
using EmployerRegistration.Model;
using AutoMapper;
using Microsoft.Extensions.Options;
using EmployerRegistration.DataProvider.EFCore.Models;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace EmployerRegistration.DataProvider.EFRepository
{
    public class EmployerProfileDataProvider : IEmployerProfileDataProvider
    {
        private IMapper mapper;
        private ConnectionString connection;

        public EmployerProfileDataProvider(IMapper map,IOptions<ConnectionString> conn)
        {
            mapper = map;
            connection = conn.Value;
        }
        public int AddEmployerProfileInfo(EmployerProfileInfoViewModel model)
        {
            EmployerRegistrationContext erContext = new EmployerRegistrationContext(connection.EmployerRegistrationDB);

            var efcoredata = mapper.Map<EmployerProfileInfo>(model);

            var checkIfProfileInfoExist = erContext.EmployerProfileInfo.Where(p => p.Erid == efcoredata.Erid).FirstOrDefault();

            if (checkIfProfileInfoExist == null)
            {
                erContext.EmployerProfileInfo.Add(efcoredata);
            }
            else
            {
                erContext.Entry(efcoredata).CurrentValues.SetValues(model);
                erContext.Entry(efcoredata).State = EntityState.Modified;
            }

            var result = erContext.SaveChanges();

            erContext.Dispose();

            return result;
        }

        public List<EmployerProfileInfoViewModel> GetEmployerProfileInfo()
        {
            EmployerRegistrationContext erContext = new EmployerRegistrationContext(connection.EmployerRegistrationDB);

            var data = erContext.EmployerProfileInfo
                                  .Include(p => p.EmployerContactInfo)
                                  .Where(p => p.Id > 0).ToList();

            var result = mapper.Map<List<EmployerProfileInfoViewModel>>(data);

            erContext.Dispose();
            return result;
        }
    }
}

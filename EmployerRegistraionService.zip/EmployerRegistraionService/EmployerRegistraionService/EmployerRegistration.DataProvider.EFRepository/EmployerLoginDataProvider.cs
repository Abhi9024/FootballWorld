﻿using EmployerRegistration.DataProvider.IRepository;
using System;
using System.Collections.Generic;
using System.Text;
using EmployerRegistration.Model;
using AutoMapper;
using Microsoft.Extensions.Options;
using EmployerRegistration.DataProvider.EFCore.Models;
using System.Security.Cryptography;
using System.Linq;
using EmployerRegistration.BusinessLayer.Encryptor;

namespace EmployerRegistration.DataProvider.EFRepository
{
    public class EmployerLoginDataProvider : IEmployerLoginDataProvider
    {
        private IMapper mapper;
        private ConnectionString connection;

        public EmployerLoginDataProvider(IMapper map,IOptions<ConnectionString> conn)
        {
            mapper = map;
            connection = conn.Value;
        }

        public int AddEmployerLoginInfo(EmployerLoginViewModel model)
        {
            EmployerRegistrationContext erContext = new EmployerRegistrationContext(connection.EmployerRegistrationDB);
           var randomNumber = DataEncryptor.GenerateRandomNumber();

           var hashedPassword = DataEncryptor.HashPaswordWithSalt(model.Password, randomNumber);

            model.Password = hashedPassword;
            model.PasswordKey = randomNumber;

            var coreData = mapper.Map<EmployerLoginInfo>(model);

            erContext.EmployerLoginInfo.Add(coreData);
           var result = erContext.SaveChanges();

            erContext.Dispose();
            return result;
        }
        
        public List<EmployerLoginViewModel> GetEmployerLoginInfo()
        {
            EmployerRegistrationContext erContext = new EmployerRegistrationContext(connection.EmployerRegistrationDB);

            var data = erContext.EmployerLoginInfo.Where(l => l.Id > 0).ToList();

            var result = mapper.Map<List<EmployerLoginViewModel>>(data);
            erContext.Dispose();
            return result;
        }
    }
}

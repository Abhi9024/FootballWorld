﻿using AutoMapper;
using Carrier.DataProvider.EFCore.Models;
using Carrier.DataProvider.IRepository;
using Carrier.Model;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System.Collections.Generic;
using System.Linq;
using System;

namespace Carrier.DataProvider.EFRepository
{
    /// <summary>
    /// Data Provider to perform all CRUD operations. 
    /// </summary>
    public class CarrierInfoDataProvider : ICarrierInfoDataProvider
    {
        private readonly IMapper mapper;
        private readonly ConnectionStrings connection;
       
        public CarrierInfoDataProvider(IMapper map, IOptions<ConnectionStrings> conn)
        {
            mapper = map;
            connection = conn.Value;
        }

        /// <summary>
        /// Method that adds carrier details.
        /// </summary>
        /// <param name="carrier"></param>
        /// <returns></returns>
        public int AddCarrier(CarrierViewModel carrier)
        {
            CarrierContext carrierContext = new CarrierContext(connection.CarrierDatabase);

            var carrierInfo = mapper.Map<EFCore.Models.Carrier>(carrier);

            carrierContext.Carrier.Add(carrierInfo);
            int result = 0;

            try
            {
                result = carrierContext.SaveChanges();
            }
            catch (Exception e)
            {                
                throw new Exception("Failed to save carrier Information", e.InnerException);
            }
            finally
            {
                carrierContext.Dispose();
            }

            return result;
        }

        /// <summary>
        /// Method that returns the list of carriers available for the given carrier name and state.
        /// </summary>
        /// <param name="carrierName"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        public List<CarrierInformationViewModel> GetAllCarrierInfo(string carrierName, string state)
        {
            CarrierContext carrierContext = new CarrierContext(connection.CarrierDatabase);

            var data = carrierContext.Carrier
                                      .Where(c => c.CarrierName.Contains(carrierName) && c.State == state).ToList();

            var result = mapper.Map<List<CarrierInformationViewModel>>(data);

            carrierContext.Dispose();

            return result;
        }

        /// <summary>
        /// Gets the list of carriers available.
        /// </summary>
        /// <returns></returns>
        public List<CarrierInformationViewModel> GetAllCarrierInfo()
        {
            CarrierContext carrierContext = new CarrierContext(connection.CarrierDatabase);
            var data = carrierContext.Carrier.ToList();

            var result = mapper.Map<List<CarrierInformationViewModel>>(data);
            return result;
        }


        /// <summary>
        /// This method returns the detailed infor about a carrier.  
        /// </summary>
        /// <param name="carrierId"></param>
        /// <returns></returns>
        public CarrierViewModel GetCarrierInfo(int carrierId)
        {
            CarrierContext carrierContext = new CarrierContext(connection.CarrierDatabase);

            var data = carrierContext.Carrier
                                      .Include(c => c.CarrierAttributes)
                                      .Include(c => c.CarrierDisclaimer)
                                      .Where(c => c.CarrierId == carrierId).FirstOrDefault();

            var result = mapper.Map<CarrierViewModel>(data);

            carrierContext.Dispose();

            return result;
        }
    }
}

﻿using Carrier.Model;
using System.Collections.Generic;

namespace Carrier.DataProvider.IRepository
{
    /// <summary>
    /// Interface to provide all the CRUD operations related to carrier database.
    /// </summary>
    public interface ICarrierInfoDataProvider
    {

        List<CarrierInformationViewModel> GetAllCarrierInfo(string carrierName,string state);
        CarrierViewModel GetCarrierInfo(int carrierId);
        int AddCarrier(CarrierViewModel carrier);
        List<CarrierInformationViewModel> GetAllCarrierInfo();
    }
}

﻿using Carrier.DataProvider.IRepository;
using Carrier.Model;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

 namespace CarrierService.Controllers
{
    [Route("api/Carrier")]
    [EnableCors("MyPolicy")]
    public class CarrierController : Controller
    {
        private readonly ICarrierInfoDataProvider carrierInfoDataProvider;

        public CarrierController(ICarrierInfoDataProvider dataProvider)
        {
            carrierInfoDataProvider = dataProvider;
        }

        // GET api/Carrier/GetAllCarrier
        [HttpGet]
        [Route("GetAllCarrier")]
        public List<CarrierInformationViewModel> GetAllCarrierInfo()
        {
            var result = carrierInfoDataProvider.GetAllCarrierInfo();
            return result;
        }

        // GET api/Carrier/GetAllCarrierInfo?carrierName{},state{}
        [HttpGet]
        [Route("GetAllCarrierInfo")]
        public List<CarrierInformationViewModel> GetAllCarrierInfo(string carrierName,string state)
        {
            var result = carrierInfoDataProvider.GetAllCarrierInfo(carrierName,state);
            return result;
        }

        // GET api/Carrier/GetCarrierInfo?carrierId{}
        [HttpGet("{carrierId}")]
        [Route("GetCarrierInfo")]
        public CarrierViewModel GetCarrierInfo(int carrierId)
        {
            var result = carrierInfoDataProvider.GetCarrierInfo(carrierId);
            return result;
        }

        //POST api/Carrier/AddCarrier
        [HttpPost]
        [Route("AddCarrier")]
        public int AddCarrier([FromBody]CarrierViewModel carrier)
        {
            var result = carrierInfoDataProvider.AddCarrier(carrier);
            return result;
        }
    }
}

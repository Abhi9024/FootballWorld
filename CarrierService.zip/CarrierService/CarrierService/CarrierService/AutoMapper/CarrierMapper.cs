﻿using AutoMapper;
using Carrier.Model;

namespace CarrierService.AutoMapper
{
    /// <summary>
    /// Mapper class to map core models to view models.
    /// </summary>
    public class CarrierMapper:Profile
    {
        public CarrierMapper()
        {
            CreateMap<Carrier.DataProvider.EFCore.Models.Carrier, CarrierInformationViewModel>().ReverseMap();
            CreateMap<Carrier.DataProvider.EFCore.Models.CarrierAttributes, CarrierAttributesViewModel>().ReverseMap();
            CreateMap<Carrier.DataProvider.EFCore.Models.CarrierDisclaimer, CarrierDisclaimerViewModel>().ReverseMap();
            CreateMap<Carrier.DataProvider.EFCore.Models.Carrier, CarrierViewModel>().ReverseMap();
        }
    }
}

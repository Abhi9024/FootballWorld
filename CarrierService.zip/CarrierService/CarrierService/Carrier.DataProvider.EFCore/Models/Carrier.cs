﻿using System;
using System.Collections.Generic;

namespace Carrier.DataProvider.EFCore.Models
{
    public partial class Carrier
    {
        public Carrier()
        {
            CarrierAttributes = new HashSet<CarrierAttributes>();
            CarrierDisclaimer = new HashSet<CarrierDisclaimer>();
        }

        public long Id { get; set; }
        public long CarrierId { get; set; }
        public string CarrierName { get; set; }
        public string CarrierShortName { get; set; }
        public long CarrierType { get; set; }
        public string State { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime TerminationDate { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? DateUserCreated { get; set; }
        public DateTime? DateModified { get; set; }
        public DateTime? DateUserModified { get; set; }

        public virtual ICollection<CarrierAttributes> CarrierAttributes { get; set; }
        public virtual ICollection<CarrierDisclaimer> CarrierDisclaimer { get; set; }
        public virtual CarrierType CarrierTypeNavigation { get; set; }
        public virtual State StateNavigation { get; set; }
    }
}

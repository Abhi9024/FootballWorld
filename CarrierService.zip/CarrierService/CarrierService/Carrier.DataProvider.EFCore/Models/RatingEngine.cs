﻿using System.Collections.Generic;

namespace Carrier.DataProvider.EFCore.Models
{
    public partial class RatingEngine
    {
        public RatingEngine()
        {
            CarrierAttributes = new HashSet<CarrierAttributes>();
        }

        public long Id { get; set; }
        public string RatingName { get; set; }

        public virtual ICollection<CarrierAttributes> CarrierAttributes { get; set; }
    }
}

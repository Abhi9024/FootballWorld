﻿using System;

namespace Carrier.DataProvider.EFCore.Models
{
    public partial class CarrierDisclaimer
    {
        public long Id { get; set; }
        public long CarrierId { get; set; }
        public string DisclaimerText { get; set; }
        public long ProductTypeId { get; set; }
        public long SortOrder { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime TerminationDate { get; set; }
        public DateTime? DateCreated { get; set; }
        public long? CreatedUserId { get; set; }
        public DateTime? DateModified { get; set; }
        public long? ModifiedUserId { get; set; }

        public virtual Carrier Carrier { get; set; }
    }
}

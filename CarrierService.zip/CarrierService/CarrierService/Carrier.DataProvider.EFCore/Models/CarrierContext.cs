﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Carrier.DataProvider.EFCore.Models
{
    public partial class CarrierContext : DbContext
    {
        private readonly string connection;

        public CarrierContext(string conn)
        {
            connection = conn;
        }
        public virtual DbSet<Carrier> Carrier { get; set; }
        public virtual DbSet<CarrierAttributes> CarrierAttributes { get; set; }
        public virtual DbSet<CarrierDisclaimer> CarrierDisclaimer { get; set; }
        public virtual DbSet<CarrierDisclaimerProductType> CarrierDisclaimerProductType { get; set; }
        public virtual DbSet<CarrierType> CarrierType { get; set; }
        public virtual DbSet<LineOfCoverage> LineOfCoverage { get; set; }
        public virtual DbSet<RatingEngine> RatingEngine { get; set; }
        public virtual DbSet<State> State { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(connection);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Carrier>(entity =>
            {
                entity.HasIndex(e => e.CarrierId)
                    .HasName("IX_Carrier")
                    .IsUnique();

                entity.Property(e => e.CarrierName)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.CarrierShortName)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.DateCreated).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.DateUserCreated).HasColumnType("datetime");

                entity.Property(e => e.DateUserModified).HasColumnType("datetime");

                entity.Property(e => e.EffectiveDate).HasColumnType("date");

                entity.Property(e => e.State)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.TerminationDate).HasColumnType("date");

                entity.HasOne(d => d.CarrierTypeNavigation)
                    .WithMany(p => p.Carrier)
                    .HasForeignKey(d => d.CarrierType)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_Carrier_CarrierType");

                entity.HasOne(d => d.StateNavigation)
                    .WithMany(p => p.Carrier)
                    .HasForeignKey(d => d.State)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_Carrier_State");
            });

            modelBuilder.Entity<CarrierAttributes>(entity =>
            {
                entity.Property(e => e.DateCreated).HasColumnType("datetime");

                entity.Property(e => e.EffectiveDate).HasColumnType("date");

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.PhysicianDirectoryUrl).HasColumnType("varchar(max)");

                entity.Property(e => e.TerminationDate).HasColumnType("date");

                entity.HasOne(d => d.Carrier)
                    .WithMany(p => p.CarrierAttributes)
                    .HasForeignKey(d => d.CarrierId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_CarrierAttributes_Carrier");

                entity.HasOne(d => d.LineOfCoverageNavigation)
                    .WithMany(p => p.CarrierAttributes)
                    .HasForeignKey(d => d.LineOfCoverage)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_CarrierAttributes_LineOfCoverage");

                entity.HasOne(d => d.RatingAlgorithmNavigation)
                    .WithMany(p => p.CarrierAttributes)
                    .HasForeignKey(d => d.RatingAlgorithm)
                    .HasConstraintName("FK_CarrierAttributes_RatingEngine");
            });

            modelBuilder.Entity<CarrierDisclaimer>(entity =>
            {
                entity.Property(e => e.DateCreated).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.DisclaimerText)
                    .IsRequired()
                    .HasColumnType("varchar(max)");

                entity.Property(e => e.EffectiveDate).HasColumnType("date");

                entity.Property(e => e.TerminationDate).HasColumnType("date");

                entity.HasOne(d => d.Carrier)
                    .WithMany(p => p.CarrierDisclaimer)
                    .HasForeignKey(d => d.CarrierId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_CarrierDisclaimer_Carrier");
            });

            modelBuilder.Entity<CarrierType>(entity =>
            {
                entity.Property(e => e.CarrierTypeId).ValueGeneratedNever();

                entity.Property(e => e.CarrierTypeName)
                    .IsRequired()
                    .HasColumnType("varchar(100)");
            });

            modelBuilder.Entity<LineOfCoverage>(entity =>
            {
                entity.HasKey(e => e.LocId)
                    .HasName("PK_LineOfCoverage");

                entity.Property(e => e.LocName)
                    .IsRequired()
                    .HasColumnType("varchar(100)");
            });

            modelBuilder.Entity<RatingEngine>(entity =>
            {
                entity.Property(e => e.RatingName)
                    .IsRequired()
                    .HasColumnType("varchar(50)");
            });

            modelBuilder.Entity<State>(entity =>
            {
                entity.HasKey(e => e.StateCode)
                    .HasName("PK_State");

                entity.Property(e => e.StateCode).HasColumnType("varchar(50)");

                entity.Property(e => e.StateName)
                    .IsRequired()
                    .HasColumnType("varchar(100)");
            });
        }
    }
}
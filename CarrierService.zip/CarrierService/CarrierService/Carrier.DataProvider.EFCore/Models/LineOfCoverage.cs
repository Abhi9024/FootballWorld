﻿using System;
using System.Collections.Generic;

namespace Carrier.DataProvider.EFCore.Models
{
    public partial class LineOfCoverage
    {
        public LineOfCoverage()
        {
            CarrierAttributes = new HashSet<CarrierAttributes>();
        }

        public long LocId { get; set; }
        public long CarrierTypeId { get; set; }
        public string LocName { get; set; }

        public virtual ICollection<CarrierAttributes> CarrierAttributes { get; set; }
    }
}

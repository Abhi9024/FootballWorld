﻿using System.Collections.Generic;

namespace Carrier.DataProvider.EFCore.Models
{
    public partial class CarrierType
    {
        public CarrierType()
        {
            Carrier = new HashSet<Carrier>();
        }

        public long CarrierTypeId { get; set; }
        public string CarrierTypeName { get; set; }

        public virtual ICollection<Carrier> Carrier { get; set; }
    }
}

﻿using System;

namespace Carrier.DataProvider.EFCore.Models
{
    public partial class CarrierAttributes
    {
        public long Id { get; set; }
        public long CarrierId { get; set; }
        public long LineOfCoverage { get; set; }
        public bool? AnicillarySetup { get; set; }
        public string PhysicianDirectoryUrl { get; set; }
        public long? RatingAlgorithm { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime TerminationDate { get; set; }
        public DateTime? DateCreated { get; set; }
        public long? CreatedUserId { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public long? ModifiedUserId { get; set; }

        public virtual Carrier Carrier { get; set; }
        public virtual LineOfCoverage LineOfCoverageNavigation { get; set; }
        public virtual RatingEngine RatingAlgorithmNavigation { get; set; }
    }
}

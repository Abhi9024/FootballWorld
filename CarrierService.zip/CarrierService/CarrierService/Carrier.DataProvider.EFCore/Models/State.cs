﻿using System.Collections.Generic;

namespace Carrier.DataProvider.EFCore.Models
{
    public partial class State
    {
        public State()
        {
            Carrier = new HashSet<Carrier>();
        }

        public string StateCode { get; set; }
        public string StateName { get; set; }

        public virtual ICollection<Carrier> Carrier { get; set; }
    }
}

﻿namespace Carrier.DataProvider.EFCore.Models
{
    public partial class CarrierDisclaimerProductType
    {
        public long Id { get; set; }
        public long CarrierDisclaimerId { get; set; }
        public long ProductId { get; set; }
    }
}

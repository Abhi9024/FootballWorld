﻿using System;

namespace Carrier.Model
{
    /// <summary>
    /// Carrier Attributes view model.
    /// </summary>
    public class CarrierAttributesViewModel
    {
        public long Id { get; set; }
        public long CarrierId { get; set; }
        public long LineOfCoverage { get; set; }
        public bool? AnicillarySetup { get; set; }
        public string PhysicianDirectoryUrl { get; set; }
        public long? RatingAlgorithm { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime TerminationDate { get; set; }
        public DateTime? DateCreated { get; set; }
        public long? CreatedUserId { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public long? ModifiedUserId { get; set; }

        public virtual LineOfCoverageViewModel LineOfCoverageNavigation { get; set; }
        public virtual RatingEngineViewModel RatingAlgorithmNavigation { get; set; }
    }
}
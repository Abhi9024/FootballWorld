﻿using System.Collections.Generic;

namespace Carrier.Model
{
    /// <summary>
    /// Line of coverage view model for each carrier types.
    /// </summary>
    public class LineOfCoverageViewModel
    {
        public long LocId { get; set; }
        public long CarrierTypeId { get; set; }
        public string LocName { get; set; }

        public virtual ICollection<CarrierAttributesViewModel> CarrierAttributes { get; set; }
    }
}
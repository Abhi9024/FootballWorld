﻿namespace Carrier.Model
{
    public class ConnectionStrings
    {
        public string CarrierDatabase { get; set; }
    }
}
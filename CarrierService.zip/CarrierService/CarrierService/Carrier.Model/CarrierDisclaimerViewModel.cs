﻿using System;

namespace Carrier.Model
{
    /// <summary>
    /// Carrier Disclaimer view model.
    /// </summary>
    public class CarrierDisclaimerViewModel
    {
        public long Id { get; set; }
        public long CarrierId { get; set; }
        public string DisclaimerText { get; set; }
        public long ProductTypeId { get; set; }
        public long SortOrder { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime TerminationDate { get; set; }
        public DateTime? DateCreated { get; set; }
        public long? CreatedUserId { get; set; }
        public DateTime? DateModified { get; set; }
        public long? ModifiedUserId { get; set; }

    }
}
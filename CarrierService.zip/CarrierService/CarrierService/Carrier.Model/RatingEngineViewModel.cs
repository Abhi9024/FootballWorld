﻿using System.Collections.Generic;

namespace Carrier.Model
{
    /// <summary>
    /// Rating engine view model.
    /// </summary>
    public class RatingEngineViewModel
    {
        public long Id { get; set; }
        public string RatingName { get; set; }

        public virtual ICollection<CarrierAttributesViewModel> CarrierAttributes { get; set; }
    }
}
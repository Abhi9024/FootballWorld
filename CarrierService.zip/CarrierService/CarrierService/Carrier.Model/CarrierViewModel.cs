﻿using System;
using System.Collections.Generic;

namespace Carrier.Model
{
    /// <summary>
    /// Carrier View Model.
    /// </summary>
    public class CarrierViewModel
    {
        public long Id { get; set; }
        public long CarrierId { get; set; }
        public string CarrierName { get; set; }
        public string CarrierShortName { get; set; }
        public long CarrierType { get; set; }
        public string State { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime TerminationDate { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? DateUserCreated { get; set; }
        public DateTime? DateModified { get; set; }
        public DateTime? DateUserModified { get; set; }


        public virtual ICollection<CarrierAttributesViewModel> CarrierAttributes { get; set; }
        public virtual ICollection<CarrierDisclaimerViewModel> CarrierDisclaimer { get; set; }
        public virtual CarrierTypeViewModel CarrierTypeNavigation { get; set; }
        public virtual StateViewModel StateNavigation { get; set; }
    }
}

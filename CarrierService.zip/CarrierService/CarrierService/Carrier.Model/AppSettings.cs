﻿namespace Carrier.Model
{
    public class AppSettings
    {
        public ConnectionStrings ConnectionString { get; set; }
    }
}

﻿using System.Collections.Generic;

namespace Carrier.Model
{
    /// <summary>
    /// State View model.
    /// </summary>
    public class StateViewModel
    {
       
            public StateViewModel()
            {
                Carrier = new HashSet<CarrierInformationViewModel>();
            }

            public string StateCode { get; set; }
            public string StateName { get; set; }

            public virtual ICollection<CarrierInformationViewModel> Carrier { get; set; }
        
    }
}

﻿using System.Collections.Generic;

namespace Carrier.Model
{
    /// <summary>
    /// Carrier type view model. Either Medical or Ancillary.
    /// </summary>
    public class CarrierTypeViewModel
    {
            public CarrierTypeViewModel()
            {
                Carrier = new HashSet<CarrierInformationViewModel>();
            }

            public long CarrierTypeId { get; set; }
            public string CarrierTypeName { get; set; }

            public virtual ICollection<CarrierInformationViewModel> Carrier { get; set; }

    }
}

﻿using System;

namespace Carrier.Model
{
    /// <summary>
    /// Carrier Information view model.
    /// </summary>
    public class CarrierInformationViewModel
    {
        public long CarrierId { get; set; }
        public string CarrierName { get; set; }
        public string CarrierShortName { get; set; }
        public long CarrierType { get; set; }
        public string State { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime TerminationDate { get; set; }
    }
}

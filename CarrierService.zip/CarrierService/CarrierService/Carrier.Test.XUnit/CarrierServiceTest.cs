using Carrier.Model;
using Carrier.Test.XUnit.Helper;
using CarrierService.Controllers;
using System;
using System.Collections.Generic;
using Xunit;

namespace Carrier.Test.XUnit
{
    public class CarrierServiceTest
    {
        private CarrierTestHelper helper = new CarrierTestHelper();

        [Theory]
        [InlineData("ACME", "AZ")]
        public void GetAllCarrierInfoTest(string carrierName, string state)
        {
            //arrange
            var moqResult = new List<CarrierInformationViewModel>();

            moqResult.Add(new CarrierInformationViewModel()
            {
                CarrierId = 1,
            });
            moqResult.Add(new CarrierInformationViewModel()
            {
                CarrierId = 5,
            });
            moqResult.Add(new CarrierInformationViewModel()
            {
                CarrierId = 15,
            });
            moqResult.Add(new CarrierInformationViewModel()
            {
                CarrierId = 16,
            });

            CarrierController carrierService = new CarrierController(helper.GetAllCarrierInfo(carrierName, state, moqResult));

            var expectedResult = new List<CarrierInformationViewModel>();
            expectedResult.Add(new CarrierInformationViewModel()
            {
                CarrierId = 1,
            });
            expectedResult.Add(new CarrierInformationViewModel()
            {
                CarrierId = 5,
            });
            expectedResult.Add(new CarrierInformationViewModel()
            {
                CarrierId = 15,
            });
            expectedResult.Add(new CarrierInformationViewModel()
            {
                CarrierId = 16,
            });

            //act
            var actualResult = carrierService.GetAllCarrierInfo(carrierName, state);

            //assert
            Assert.Equal(expectedResult.Count, actualResult.Count);
        }

        [Theory]
        [InlineData("ACME", "AZ")]
        public void GetAllCarrierInfoTestNotEqual(string carrierName, string state)
        {
            //arrange
            var moqResult = new List<CarrierInformationViewModel>();

            moqResult.Add(
            new CarrierInformationViewModel()
            {
                CarrierId = 1,
            });


            CarrierController carrierService = new CarrierController(helper.GetAllCarrierInfo(carrierName, state, moqResult));

            var expectedResult = new List<CarrierInformationViewModel>();
            expectedResult.Add(new CarrierInformationViewModel()
            {
                CarrierId = 1,
            });
            expectedResult.Add(new CarrierInformationViewModel()
            {
                CarrierId = 1,
            });

            //act
            var actualResult = carrierService.GetAllCarrierInfo(carrierName, state);

            //assert
            Assert.NotEqual(expectedResult.Count, actualResult.Count);
        }


        [Theory]
        [InlineData(1)]
        public void GetCarrierInfoTest(int carrierId)
        {
            //arrange
            var moqResult = new CarrierViewModel();

            moqResult.CarrierAttributes = new List<CarrierAttributesViewModel>() { new CarrierAttributesViewModel() { CarrierId = 1 }, new CarrierAttributesViewModel() { CarrierId = 1 } };

            CarrierController carrierService = new CarrierController(helper.GetCarrierInfo(carrierId, moqResult));

            var expectedResult = new CarrierViewModel();
            expectedResult.CarrierAttributes = new List<CarrierAttributesViewModel>() { new CarrierAttributesViewModel() { CarrierId = 1 }, new CarrierAttributesViewModel() { CarrierId = 1 } };

            //act
            var actualResult = carrierService.GetCarrierInfo(carrierId);

            //assert
            Assert.Equal(expectedResult.CarrierAttributes.Count, actualResult.CarrierAttributes.Count);
        }

        [Theory]
        [InlineData(2)]
        public void GetCarrierInfoTestNotEqual(int carrierId)
        {
            //arrange
            var moqResult = new CarrierViewModel();

            moqResult.CarrierAttributes = new List<CarrierAttributesViewModel>() { new CarrierAttributesViewModel() { CarrierId = 1 }, new CarrierAttributesViewModel() { CarrierId = 1 } };

            CarrierController carrierService = new CarrierController(helper.GetCarrierInfo(carrierId, moqResult));

            var expectedResult = new CarrierViewModel();
            expectedResult.CarrierAttributes = new List<CarrierAttributesViewModel>() { new CarrierAttributesViewModel() { CarrierId = 1 }, new CarrierAttributesViewModel() { CarrierId = 1 }, new CarrierAttributesViewModel() { CarrierId = 1 } };

            //act
            var actualResult = carrierService.GetCarrierInfo(carrierId);

            //assert
            Assert.NotEqual(expectedResult.CarrierAttributes.Count, actualResult.CarrierAttributes.Count);
        }

        [Fact]
        public void AddCarrierInfoTest()
        {
            //arrange
            var carrierInfoTest = SetUpCarrierViewModel();
            int moqResult = 3;
            CarrierController carrierService = new CarrierController(helper.AddCarrierInfoTest(carrierInfoTest, moqResult));

            var expectedResult = 3;
            //act
            var actualResult = carrierService.AddCarrier(carrierInfoTest);
            //assert
            Assert.Equal(actualResult, expectedResult);
        }

        private CarrierViewModel SetUpCarrierViewModel()
        {
            var carrierInfo = new CarrierViewModel()
            {
                CarrierId = 24,
                CarrierName = "Healthnet test1",
                CarrierShortName = "Healthnet test1",
                CarrierType = 2,
                State = "AZ",
                EffectiveDate = DateTime.Now,
                TerminationDate = DateTime.Now,
            };
            var carrierAttributes = new CarrierAttributesViewModel()
            {

                LineOfCoverage = 1,

                RatingAlgorithm = 1,
                EffectiveDate = DateTime.Now,
                TerminationDate = DateTime.Now,
            };

            var carrierDisclaimer = new CarrierDisclaimerViewModel()
            {

                DisclaimerText = "This is test disclaimer text",
                ProductTypeId = 1,
                SortOrder = 1,
                EffectiveDate = DateTime.Now,
                TerminationDate = DateTime.Now,

            };

            carrierInfo.CarrierAttributes = new List<CarrierAttributesViewModel>();
            carrierInfo.CarrierDisclaimer = new List<CarrierDisclaimerViewModel>();
            carrierInfo.CarrierAttributes.Add(carrierAttributes);
            carrierInfo.CarrierDisclaimer.Add(carrierDisclaimer);

            return carrierInfo;
        }
    }
}

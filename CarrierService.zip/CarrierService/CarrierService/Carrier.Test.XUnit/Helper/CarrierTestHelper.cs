﻿using AutoMapper;
using Carrier.DataProvider.EFRepository;
using Carrier.DataProvider.IRepository;
using Carrier.Model;
using Moq;
using System.Collections.Generic;

namespace Carrier.Test.XUnit.Helper
{
    /// <summary>
    /// Helper method for unit testing.
    /// </summary>
    public class CarrierTestHelper
    {
        private static IConfigurationProvider configurationProvider;
        private readonly string testmethod = "Moq";

        private IMapper mapper;

        Mock<ICarrierInfoDataProvider> carrierInfoMoq = new Mock<ICarrierInfoDataProvider>();

        /// <summary>
        /// Method used to return a complex object based on the test method type, either moq or integration test. 
        /// </summary>
        /// <param name="carrierName"></param>
        /// <param name="state"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        public ICarrierInfoDataProvider GetAllCarrierInfo(string carrierName, string state,List<CarrierInformationViewModel> result)
        {
            if (testmethod == "Moq")
            {
                carrierInfoMoq.Setup(x => x.GetAllCarrierInfo(carrierName, state)).Returns(result);
                return carrierInfoMoq.Object;
            }
            else
            {
                var mapperConfig = new MapperConfiguration(cfg =>
                {
                    cfg.AddProfile(new CarrierMapperTest());
                });

                mapper = mapperConfig.CreateMapper();

                return new CarrierInfoDataProvider(mapper, new DependencyResolver().ConnectionStrings);
            }
        }

        /// <summary>
        /// Method used to return a complex object based on the test method type, either moq or integration test. 
        /// </summary>
        /// <param name="carrierName"></param>
        /// <param name="state"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        public ICarrierInfoDataProvider GetCarrierInfo(int carrierid, CarrierViewModel result)
        {
            if (testmethod == "Moq")
            {
                carrierInfoMoq.Setup(x => x.GetCarrierInfo(carrierid)).Returns(result);
                return carrierInfoMoq.Object;
            }
            else
            {
                var mapperConfig = new MapperConfiguration(cfg =>
                {
                    cfg.AddProfile(new CarrierMapperTest());
                });

                mapper = mapperConfig.CreateMapper();

                return new CarrierInfoDataProvider(mapper, new DependencyResolver().ConnectionStrings);
            }
        }

        public ICarrierInfoDataProvider AddCarrierInfoTest(CarrierViewModel input,int result)
        {
            if (testmethod == "Moq")
            {
                carrierInfoMoq.Setup(x => x.AddCarrier(input)).Returns(result);
                return carrierInfoMoq.Object;
            }
            else
            {
                var mapperConfig = new MapperConfiguration(cfg =>
                {
                    cfg.AddProfile(new CarrierMapperTest());
                });

                mapper = mapperConfig.CreateMapper();

                return new CarrierInfoDataProvider(mapper, new DependencyResolver().ConnectionStrings);
            }
        }

    }
}

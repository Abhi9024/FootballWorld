﻿using AutoMapper;
using Carrier.Model;

namespace Carrier.Test.XUnit.Helper
{
    /// <summary>
    /// Mapper for mapping core models to view models
    /// </summary>
    public class CarrierMapperTest : Profile
    {
        public CarrierMapperTest()
        {
            CreateMap<DataProvider.EFCore.Models.Carrier, CarrierInformationViewModel>().ReverseMap();
            CreateMap<DataProvider.EFCore.Models.CarrierAttributes, CarrierAttributesViewModel>().ReverseMap();
            CreateMap<DataProvider.EFCore.Models.CarrierDisclaimer, CarrierDisclaimerViewModel>().ReverseMap();
            CreateMap<DataProvider.EFCore.Models.Carrier, CarrierViewModel>().ReverseMap();
        }
    }
}

﻿using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Carrier.DataProvider.EFRepository;
using Carrier.DataProvider.IRepository;
using Carrier.Model;
using System;

namespace Carrier.Test.XUnit.Helper
{
    /// <summary>
    /// Dependency resolver for unit testing.
    /// </summary>
    public class DependencyResolver
    {
        private readonly IConfigurationRoot Configuration;
        private readonly IServiceProvider _serviceProvider;

        public IOptions<ConnectionStrings> ConnectionStrings { get; set; }

        public DependencyResolver()
        {
            var builder = new ConfigurationBuilder()
            .AddJsonFile("testsettings.json")
            .AddEnvironmentVariables();
            Configuration = builder.Build();

            var services = new ServiceCollection();
            services.AddOptions();
            services.AddAutoMapper();
            services.Configure<ConnectionStrings>(Configuration.GetSection("ConnectionString"));
            services.AddTransient<ICarrierInfoDataProvider, CarrierInfoDataProvider>();
            _serviceProvider = services.BuildServiceProvider();
            ConnectionStrings = _serviceProvider.GetService<IOptions<ConnectionStrings>>();
        }
    }
}
